#include <iostream>
#include <string>
#include "character.h"
using namespace std;

void character::help() {
	cout << "Commands must be no more than 2 words long, seperated by a space" << endl;
	cout << "Some available commands are: go, attack, search, inspect, get, drop, use" << endl;
	cout << "There are others as well, mostly intuitive" << endl;
}

void character::defend(int dam, int arpen, int pDam, int fDam) {
	hp -= (dam + arpen - armorRating);
	if (!fireImmune) {
		hp -= fDam;
	}
	if (!poisonImmune) {
		hp -= pDam;
	}
}

void character::getStats() {
	string fire = (fireImmune) ? "Yes" : "No";
	string poison = (poisonImmune) ? "Yes" : "No";
	cout << name << "\nHP: " << hp << "\nArmorRating: " << armorRating << "\nDamage: " << damage;
	cout << "\nFire Immunity: " << fire;
	cout << "\nPoison Immunity: " << poison;
	if (myArmor) {
		cout << "\nArmor: " << myArmor;
	}
	if (myWeapon) {
		cout << "\nWeapon: " << myWeapon;
	}
	if (myRing) {
		cout << "\nRing: " << myRing << endl;
	}
}

void character::lookinbag() {
	cout << "Bag contains: " << endl;
	for (auto item : bag) {
		cout << item->getName() << endl;
	}
}

void character::inspectItem(string s) {
	for (auto item : bag) {
		if (s == item->getName()) {
			item->inspection();
			return;
		}
	}
	if (s == myWeapon->getName()) {
		myWeapon->inspection();
		return;
	}
	if (s == myArmor->getName()) {
		myArmor->inspection();
		return;
	}
	if (s == myRing->getName()) {
		myRing->inspection();
		return;
	}
	cout << s << " doesn't seem to be an object or item here." << endl;
}

bool character::hasKey(Item* i) {
	for (auto item : bag) {
		if (i == item) {
			return true;
		}
	}
	return false;
}

void character::addItemtoBag(Item* i) {
	for (auto item : bag) {
		if (item == i) {
			cout << "You already have " << i->getName() << endl;
			return;
		}
	}
	bag.push_back(i);
}

void character::equipItem(string s) {
	for (auto item : bag) {
		if (item->getName() == s) {
			item->equip(this);
		}
	}
}