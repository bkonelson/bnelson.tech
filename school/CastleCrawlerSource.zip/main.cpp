#include <iostream>
#include <string>
#include "Room.h"
#include "commands.h"
using namespace std;

int main() {
	string playername;
	cout << "Enter a name for your character: ";
	cin >> playername;
	character* player1 = new character();
	player1->name = playername;
	int curChoice;
	cout << "\nWelcome to Castle Crawler 1.0 " << player1->name << ", choose what you will do!" << endl;
	cout << "   1.  Enter the castle and prepare to meet certain death" << endl;
	cout << "   2.  Flee like a patsy" << endl;
	cin >> curChoice;
	if (curChoice == 1) {
		cout << "Stage Info \nName: Castle Basic Bro\nHidden Rooms: 0\nArtifacts: 0" << endl;

		//Rooms
		Room room1("Entry Hall",0,0,2,0);
		Room room2("Training Ground", 4, 0, 3, 1);
		Room room3("Armory", 0, 0, 0, 2);
		Room room4("Throne Room", 99, 2, 0, 0);
		
		//Doors
		Door e1door("east", false, 5, true);
		Door e2door("east", true, 1, true);
		Door w2door("west", false, 0, false);
		Door n2door("north", true, 1, true);
		Door w3door("west", true, 1, false);
		Door s4door("south", true, 1, false);
		Door n4door("north", true, 1, true);

		//Furnishings and item creation
		Furnishing table("table", true, 1);
		Chest chest1("wooden chest", false, 10, false, true, false);
		Weapon sword1("basic sword", 3);
		Chest chest2("ornate chest", true, 1, false, true, true);
		Painting paint1("Mountain painting", true, 1, "A painting of a mountain with a snow covered peak", "Jimbo");
		Chest armorRack("Armor Rack", true, 1, nullptr, false, false);
		Furnishing chair("plain chair", false, 5);
		Furnishing dummy("practice dummy", true, 1);
		Furnishing archery("archery target", true, 1);

		//Monsters

		//Adding doors to rooms
		room1.addDoor(&e1door);
		room2.addDoor(&e2door);
		room2.addDoor(&w2door);
		room2.addDoor(&n2door);
		room3.addDoor(&w3door);
		room4.addDoor(&s4door);
		room4.addDoor(&n4door);

		//Adding Furnishings to rooms
		room1.addFurn(&table);
		room1.addFurn(&chest1);
		room2.addFurn(&archery);
		room2.addFurn(&dummy);
		room2.addFurn(&chair);
		room3.addFurn(&chest2);
		room3.addFurn(&armorRack);
		room3.addFurn(&paint1);

		//Add Monsters to rooms

		//Add items to containers
		chest1.addItem(&sword1);
		
		//Main Loop
		cin.ignore();
		cout << "You enter the " << room1.getName() << ".  [type 'help' for a list of available commands]" << endl;
		Room* curRoom = &room1;
		int move = 0;
		bool end = false;
		while (!end) {
			int move = commands(player1,curRoom);
			switch (move) {
				case 0:
					break;
				case 1:
					curRoom = &room1;
					break;
				case 2:
					curRoom = &room2;
					break;
				case 3:
					curRoom = &room3;
					break;
				case 4:
					curRoom = &room4;
					break;
				case 99:
					end = true;
					break;
			}
			if (move != 0) {
				cout << "You enter the " << curRoom->getName() << endl;
			}
		}
		cout << "You have defeated the ogre and won the heart of the princess" << endl;
		cout << "Just kidding.......there was no princess, you got a pretty nice sword though right?" << endl;
		cin;




	}
	else {
		cout << "Really? Fine....you flee and remain an indetured servant the rest of your life";
		cout << " interestingly without any dentures, very poor dental hygiene." << endl;
	}

	return 0;
}