#include <iostream>
#include <string>
#include "Door.h"

using namespace std;

void Door::unlock() {
	if (!this->locked) {
		cout << this->location << " door is already unlocked." << endl;
	}
	else {
		this->locked = false;
	}
}

void Door::damageItem() {

}

void Door::takeDamage() {
	if (this->invulnerable) {
		cout << this->location << " door is invulnerable to damage." << endl;
	}
	else if (this->locked) {
		cout << this->location << " door lock has been destroyed." << endl;
		this->locked = false;
	}
	else {
		cout << "Why?" << endl;
	}
}

void Door::inspection() {
	cout << location << " door locked: " << locked;
}
