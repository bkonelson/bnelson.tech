#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "Item.h"

using namespace std;

class character {
public:
	string name;
	int hp = 10;
	int armorRating = 0;
	int damage = 1;
	Weapon* myWeapon{};
	Armor* myArmor{};
	Ring* myRing{};
	vector<Item*> bag;
	bool fireImmune = false;
	bool poisonImmune = false;
	character() {}
	void help();
	void addItemtoBag(Item* i);
	void lookinbag();
	void defend(int dam, int arpen, int pDam, int fDam);
	void getStats();
	void inspectItem(string s);
	bool hasKey(Item* i);
	void equipItem(string s);
};
