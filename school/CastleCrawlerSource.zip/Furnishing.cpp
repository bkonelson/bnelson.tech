#include <iostream>
#include <string>
#include "Furnishing.h"

using namespace std;


void Furnishing::damageItem() {

}

void Furnishing::takeDamage() {
	if (this->invulnerable) {
		cout << this->name << " is invulnerable to damage." << endl;
	}
	else if(this->destroyed) {
		cout << this->name << " has been destroyed." << endl;
	}
	else {
		this->hp = 0;
		this->name = "ruined " + name;
		this->destroyed = true;
	}
}

void Furnishing::damageCharacter() {

}

void Furnishing::inspection() {
	cout << name << ":\n" << "HP: " << hp << endl;

}



