#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "Door.h"
#include "Furnishing.h"
#include "Monster.h"
#include "character.h"

using namespace std;

class Room {
private:
	string name;
	int north;
	int south;
	int east;
	int west;
	vector<Door*> doors;
	vector<Furnishing*> stuff;
	vector<Monster*> monsters;
public:
	bool cleared;
	Room(string name, int n, int s, int e, int w): name(name), north(n),south(s),east(e), west(w) {}
	void addDoor(Door* D);
	string getName() { return name; }
	void addFurn(Furnishing* F);
	void addMonster(Monster* M);
	int go(string s);
	void openContainer(string s);
	void displaySearch();	
	void attack(string s, character* P1);
	void monsterAttack(Monster* M, character* P1);
	void unlockDoor(string s);
	Door* getDoor(string s);
	Item* getChestKey(string s);
	void unlockChest(string s);
	void inspect(string s);
	void getItemFromChest(string s, character* p1);
};