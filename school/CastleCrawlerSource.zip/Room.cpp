#include <iostream>
#include <string>
#include <iomanip>
#include "Room.h"
using namespace std;
	
void Room::addFurn(Furnishing* F) {
	stuff.push_back(F);
}

void Room::addDoor(Door* D) {
	doors.push_back(D);
}

void Room::addMonster(Monster* M) {
	monsters.push_back(M);
}

int Room::go(string s) {
	for (int i = 0; i < doors.size(); i++) {
		if (doors[i]->location == s || doors[i]->location + " door" == s) {
			if (doors[i]->locked != true) {
				if (s == "north door" || s == "north") {
					return north;
				}
				else if (s == "south door" || s == "south") {
					return south;
				}
				else if (s == "east door" || s=="east") {
					return east;
				}
				else {
					return west;
				}
			}
			else {
				cout << "The " << s << " door is locked" << endl;
				return 0;
			}
		}
	}
	cout << "There is not a door in that direction." << endl;
	return 0;
}

void Room::attack(string s, character* P1) {
	for (int i = 0; i < monsters.size(); i++) {
		if (monsters[i]->name == s) {
			int damage = P1->damage;
			int arpen = 0;
			int fire = 0;
			int poison = 0;
			monsters[i]->defend(damage,arpen,poison,fire);
			if (monsters[i]->hp <= 0) {
				cout << monsters[i]->name << " has been defeated!" << endl;

				monsters.erase(monsters.begin() + i);
			}
			else {
				monsterAttack(monsters[i], P1);
			}
			return;
		}
	}
	for (int i = 0; i < doors.size(); i++) {
		if (doors[i]->location == s || doors[i]->location + " door" == s) {
			doors[i]->takeDamage();
			doors[i]->damageItem();
			return;
		}
	}
	for (int i = 0; i < stuff.size(); i++) {
		if (stuff[i]->getName() == s) {
			stuff[i]->takeDamage();
			stuff[i]->damageItem();
			return;
		}
	}
	cout << "Cannot attack " << s << ". That does not exist in this room." << endl;
}

void Room::monsterAttack(Monster* M, character* P1) {
	int damage = M->damage;
	int arpen = 0;
	int fire = 0;
	int poison = 0;
	P1->defend(damage, arpen, poison, fire);
	if (P1->hp <= 0) {
		cout << "Game Over" << endl;
		cin;
		exit(0);
	}
}

void Room::displaySearch() {
	cout << "The " << name << " contains: " << endl;
	cout << "Doors:  ";
	bool secLoop = false;
	for (auto door : doors) {
		if (secLoop)
			cout << ", ";
		cout << door->location << " door";
		secLoop = true;
	}
	secLoop = false;
	cout << "\nFurnishings:  ";
	for (auto things : stuff) {
		if (secLoop)
			cout << ", ";
		cout << things->getName();
		secLoop = true;
	}
	secLoop = false;
	cout << "\nMonsters:  ";
	for (auto enemies : monsters) {
		if (secLoop)
			cout << ", ";
		cout  << enemies->name;
		secLoop = true;
	}
	cout << endl;
}

void Room::unlockDoor(string s) {
	for (int i = 0; i < doors.size(); i++) {
		if (doors[i]->location == s + " door") {
			doors[i]->unlock();
			cout << s << " door has been unlocked" << endl;
			return;
		}
	}
}

Door* Room::getDoor(string s) {
	for (auto door : doors) {
		if (s == door->location + " door") {
			return door;
		}
	}
	cout << "There is not a door in that direction" << endl;
}

Item* Room::getChestKey(string s) {
	for (auto chest : stuff) {
		if (s == chest->getName()) {
			return chest->getKey();
		}
	}
}

void Room::unlockChest(string s) {
	for (auto chest : stuff) {
		if (s == chest->getName()) {
			return chest->unlockChest();
		}
	}
}

void Room::openContainer(string s) {
	for (auto item : stuff) {
		if (s == item->getName()) {
			item->showContents();
		}
	}
}

void Room::getItemFromChest(string s, character* p1) {
	for (auto chest : stuff) {
		if (chest->getItem(s)) {
			p1->addItemtoBag(chest->getItem(s));
		}
	}
}

void Room::inspect(string s) {
	for (auto door : doors) {
		if (s == door->location + " door") {
			door->inspection();
			return;
		}
	}
	for (auto things : stuff) {
		if (s == things->getName()) {
			things->inspection();
			return;
		}
	}
	for (auto enemies : monsters) {
		if (s == enemies->name) {
			enemies->inspection();
			return;
		}
	}
}
