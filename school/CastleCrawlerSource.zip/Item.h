#pragma once
#include <iostream>
#include <string>
#include "character.h"

using namespace std;

class Item {
private:
	string name;
	bool pickUp;
public:
	Item(string name, bool pickUp = false) : name(name), pickUp(pickUp) {}
	void allowPickUp() { pickUp = true; }
	bool canPickUp() { return pickUp; }
	string getName(){ return name; }
	virtual void inspection() {
		cout << name << endl;
	}
	virtual void equip(character* p1) {}
};

class Armor : public Item {
public:
	int armorRating;
	Armor(string name, int armor, bool pickUp = false) : Item(name,pickUp), armorRating(armor) {}
	void inspection() {
		Item::inspection();
		cout << "Armor: " << armorRating << endl;
	}
	void equip(character* p1) {
		if (!p1->myArmor) {
			p1->myArmor = this;
		}
		else {
			p1->addItemtoBag(p1->myArmor);
			p1->armorRating -= p1->myArmor->armorRating;
			p1->myArmor = this;
		}
		p1->armorRating += this->armorRating;
	}
};

class Ring : public Item {
public:
	int armorRating;
	bool fireImmune;
	bool poisonImmune;
	Ring(string name, int armor = 0, bool poison = false, bool fire = false, bool pickUp = false)
		: Item(name,pickUp), armorRating(armor), poisonImmune(poison), fireImmune(fire) {}
	void inspection() {
		Item::inspection();
		if (armorRating != 0) {
			cout << "Armor: " << armorRating << endl;
		}
		if (poisonImmune) {
			cout << "Immunity to Poison" << endl;
		}
		if (fireImmune) {
			cout << "Immunity to Fire" << endl;
		}
	}
	void equip(character* p1) {
		if (!p1->myRing) {
			p1->myRing = this;
		}
		else {
			p1->addItemtoBag(p1->myRing);
			p1->armorRating -= p1->myRing->armorRating;
			p1->fireImmune = false;
			p1->poisonImmune = false;
			p1->myRing = this;
		}
		p1->armorRating += this->armorRating;
		p1->fireImmune = this->fireImmune;
		p1->poisonImmune = this->poisonImmune;
	}
};

class Weapon : public Item {
public:
	int damage;
	int armorPen;
	int pDamage;
	int fDamage;
	Weapon(string name, int damage, int armp = 0, int pDam = 0, int fDam = 0, bool pickUp = false)
		: Item(name,pickUp), damage(damage), armorPen(armp), pDamage(pDam), fDamage(fDam) {}
	void inspection() {
		Item::inspection();
		cout << "Damage: " << damage << endl;
		if (armorPen != 0) {
			cout << "Armor Damage: " << armorPen << endl;
		}
		if (pDamage != 0) {
			cout << "Fire Damage: " << pDamage << endl;
		}
		if (fDamage != 0) {
			cout << "Poison Damage: " << fDamage << endl;
		}
	}
	void equip(character* p1) {
		if (!p1->myWeapon) {
			p1->myWeapon = this;
		}
		else {
			p1->addItemtoBag(p1->myWeapon);
			p1->myWeapon = this;
		}
	}
};