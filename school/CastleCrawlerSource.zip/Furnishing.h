#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "puzzle.h"
#include "Item.h"
using namespace std;

class Furnishing {
private:
	string name;
	bool invulnerable;
	int hp;
	bool destroyed;
public:
	Furnishing(string name, bool inv, int hp, bool dest = false) : name(name), invulnerable(inv), hp(hp), destroyed(dest) {}
	void damageItem();
	void takeDamage();
	void damageCharacter();
	virtual void showContents() { cout << name << " contains nothing." << endl; }
	virtual void inspection();
	string getName() { return name; }
	virtual Item* getKey() { return nullptr; }
	virtual void unlockChest() {}
	virtual Item* getItem(string s) { return nullptr; }
};

class Chest : public Furnishing {
public:
	bool trapped;
	bool locked;
	puzzle* puzzle;
	Item* key;
	vector<Item*> contents;
	Chest(string name, bool inv, int hp, Item* key = nullptr, bool dest = false, bool locked = true, bool trapped = false)
		: Furnishing(name, inv, hp, dest), key(key), locked(locked), trapped(trapped) {}
	void addItem(Item* i) {
		contents.push_back(i);
	}
	Item* getItem(string s) {
		for (int i = 0; i < contents.size(); i++) {
			if (contents[i]->getName() == s && contents[i]->canPickUp()) {
				Item* temp = contents[i];
				contents.erase(contents.begin() + i);
				return temp;
			}
			else {
				cout << "Can't pick up " << s << endl;
				return nullptr;
			}
		}
	}
	Item* getKey(){ return key; }
	void unlockChest() {
		if (!this->locked) {
			cout << this->getName() << " is already unlocked." << endl;
		}
		else {
			this->locked = false;
			cout << "(unlocking click noise)" << endl;
		}
	}
	void disarm() {
		if (!this->trapped) {
			cout << this->getName() << " is already disarmed." << endl;
		}
		else {
			this->trapped = false;
		}
	}
	void showContents() {
		if (!this->locked) {
			cout << this->getName() << " contains: " << endl;
			for (auto item : contents) {
				item->allowPickUp();
				cout << item->getName() << endl;
			}
		}
		else {
			cout << this->getName() << " is locked." << endl;
		}
	}
	void inspection() {
		cout << this->getName() << ":\nlocked: " << locked << endl;
	}
};

class Painting : public Furnishing {
public:
	string desc;
	string artist;
	bool hidden;
	Painting(string name, bool inv, int hp, string desc, string artist, bool hidden = false, bool dest = false)
		: Furnishing(name, inv, hp, dest), desc(desc), artist(artist), hidden(hidden) {}
	void showContents() {
		//do later
	}
	void inspection() {
		cout << this->getName() << ":\nArtist: " << artist << "\nDescription: " << desc << endl;
	}
	Item* getKey() { return nullptr; }
	virtual void unlockChest() {}
	virtual Item* getItem(string s) { return nullptr; }
};