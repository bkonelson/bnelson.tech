#pragma once
#include <iostream>
#include <string>
#include "puzzle.h"
#include "Item.h"

using namespace std;

class Door {
public:
	string location;
	Item* key;
	bool invulnerable;
	int hp;
	bool locked;
	Door(string loc, bool inv, int hp, bool locked, Item* key = nullptr) : location(loc), invulnerable(inv), hp(hp), locked(locked), key(key) {}
	void unlock();
	void damageItem();
	void takeDamage();
	string getLoc() { return location; }
	void inspection();
};