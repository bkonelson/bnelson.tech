#include <iostream>
#include <string>
#include "Monster.h"
using namespace std;

void Monster::defend(int dam, int arpen, int pDam, int fDam) {
	armorRating -= arpen;
	hp -= (dam - armorRating);
	if (!fireImmune) {
		hp -= fDam;
	}
	if (!poisonImmune) {
		hp -= pDam;
	}
}

void Monster::inspection() {
	string fire = (fireImmune) ? "Yes" : "No";
	string poison = (poisonImmune) ? "Yes" : "No";
	cout << name << "\nHP: " << hp << "\nArmor: " << armorRating << "\nWeakness: " << weakness;
	cout << "\nFire Immunity: " << fire;
	cout << "\nPoison Immunity: " << poison << endl;
}