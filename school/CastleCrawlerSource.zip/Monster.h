#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "Item.h"
using namespace std;

class Monster {
public:
	string name;
	int hp;
	int armorRating;
	int damage;
	int weakness;
	bool fireImmune;
	bool poisonImmune;
	vector<Item*> items;
	Monster(string name, int hp, int armor, int damage, int weakness, bool fire, bool poison) 
		: name(name), hp(hp), armorRating(armor), damage(damage), weakness(weakness), fireImmune(fire), poisonImmune(poison) {}
	void defend(int dam, int arpen, int pDam, int fDam);
	void inspection();
};